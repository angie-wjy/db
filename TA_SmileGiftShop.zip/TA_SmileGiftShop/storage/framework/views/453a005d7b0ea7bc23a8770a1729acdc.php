<?php $__env->startSection('title', 'Bundle'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Smile Gift Shop</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="#">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Bundle</a>
                </li>
            </ul>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                        <h4 class="card-title">Bundle</h4>
                        <a href="<?php echo e(route('admin.product.bundle.add')); ?>">
                            <button class="btn btn-primary">Add Bundle +</button>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <p class="alert alert-danger"><?php echo e(session('error')); ?></p>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table id="multi-filter-select" class="display table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $bundles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bundle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($bundle->id); ?></td>
                                        <td><?php echo e($bundle->name); ?></td>
                                        <td>Rp <?php echo e(number_format($bundle->price, 2, ',', '.')); ?></td>
                                        <td><?php echo e($bundle->created_at ? $bundle->created_at->format('d-m-Y H:i') : '-'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.product.bundle.edit', $bundle->id)); ?>">
                                                <button class="btn btn-primary">Edit</button>
                                            </a>
                                            <form action="<?php echo e(route('admin.product.bundle.delete', $bundle->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this bundle?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEMESTER 8\TA_SmileGiftShop\resources\views/admin/product/bundle/index.blade.php ENDPATH**/ ?>