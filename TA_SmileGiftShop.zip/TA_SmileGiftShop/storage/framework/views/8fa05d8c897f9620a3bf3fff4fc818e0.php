<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .object-fit-cover {
            object-fit: cover;
        }

        .cart_item_wrapper {
            width: 120%;
            margin: 1.5rem auto 0 auto;
            left: -10%;
            position: relative;
            padding-top: 1.5rem;
            border-radius: 1rem;
            background-color: rgb(252, 249, 249);
        }

        .cart_row_wrapper {
            display: flex;
            justify-content: flex-start;
            align-items: flex-start;
            margin-bottom: 1.5rem;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .custom-cart-checkbox {
            height: 1.8rem;
            width: 1.8rem;
            margin-right: 0.5rem;
            margin-top: 1rem;
            align-self: flex-start;
            accent-color: #fdd835;
        }

        .cart-card {
            /* max-width: 45rem; */
            width: 100%;
            margin-left: 0 auto;
            left: -10%;
            border-radius: 1rem;
        }

        .cart-image-container {
            max-width: 10rem;
            max-height: 10rem;
            overflow: hidden;
        }

        .cart-image {
            height: 100%;
            width: 100%;
            object-fit: cover;
            display: block;
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }

        .cart-details {
            padding-left: 1rem;
        }

        .cart-header {
            gap: 1rem;
        }

        .product-info .card-title {
            margin-bottom: 0.3rem;
        }

        .price {
            color: #d9534f;
        }

        .cart-actions form {
            margin: 0 0.25rem;
        }

        .cart-actions .btn {
            padding: 0.3rem 0.5rem;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .cart-actions .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .cart-actions .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .cart-actions .btn-warning {
            background-color: #fbf404;
            border-color: #fbf404;
            color: #212529;
        }

        .cart-actions .btn i {
            pointer-events: none;
        }

        .checkout-box {
            background-color: #fff;
            padding: 1.5rem;
            border-radius: 1rem;
            max-height: 50rem;
            overflow-y: auto;
            margin-left: 1rem;
            margin-bottom: 2rem;
            padding-right: -5%;
        }

        .checkout-title {
            color: #000;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .checkout-item {
            color: #fbf404;
            font-size: 1.2rem;
            margin-bottom: 0.8rem;
        }
    </style>
    <div class="content">
        <?php
            $cart = session('cart') ?? [];
        ?>

        <?php if(empty($cart)): ?>
            <h1 style="text-align: center">
                Masih belum ada item nih, yuk tambahkan
            </h1>
        <?php else: ?>
            <div class="cart_item_wrapper">
                <div class="container mt-4">
                    <div class="d-flex justify-content-between align-items-start flex-wrap">
                        
                        <div class="col-lg-8">
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cart_row_wrapper mb-3">
                                    
                                    <div class="card cart-card">
                                        <div class="row g-0">
                                            <div class="col-md-4 cart-image-container">
                                                <img src="<?php echo e(Storage::url($d['image'])); ?>" class="img-fluid cart-image"
                                                    alt="...">
                                            </div>
                                            <div class="col-md-8 d-flex align-items-center">
                                                <div class="card-body cart-details w-100">
                                                    <div class="d-flex justify-content-between cart-header">
                                                        <div>
                                                            <h4 class="card-title mb-2">
                                                                <strong><?php echo e($d['name']); ?></strong>
                                                            </h4>
                                                            <h5 class="card-title price">Rp.
                                                                <strong><?php echo e(number_format($d['price'], 0, 0, '.')); ?></strong>
                                                            </h5>
                                                        </div>
                                                        <div class="d-flex align-items-center cart-actions">
                                                            <form
                                                                action="<?php echo e(route('cart.remove', ['product_id' => $d['id']])); ?>"
                                                                method="POST" class="me-2">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger">
                                                                    <i class="ri-delete-bin-6-line"></i>
                                                                </button>
                                                            </form>
                                                            <form action="/cart/minus/<?php echo e($d['id']); ?>" method="post"
                                                                class="me-1">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-secondary">
                                                                    <i class="ri-subtract-fill"></i>
                                                                </button>
                                                            </form>
                                                            <span class="mx-2 fw-bold"><?php echo e($d['quantity']); ?></span>
                                                            <form action="/cart/plus/<?php echo e($d['id']); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-warning">
                                                                    <i class="ri-add-line"></i>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="checkout-box" id="total">
                            <?php
                                $totalHarga = 0;
                                foreach ($cart as $id => $d) {
                                    $totalHarga += $d['price'] * $d['quantity'];
                                }
                            ?>

                            <h4>
                                <span style="color: black;">Total:</span>
                                <strong style="color: #fbf404;">Rp. <?php echo e(number_format($totalHarga, 0, ',', '.')); ?></strong>
                            </h4>

                            <!-- Tombol untuk opsi metode pengiriman -->
                            <button id="optionDelivery" class="btn btn-warning mt-3">Check Out</button>

                            <!-- Form pilihan metode pengiriman, awalnya disembunyikan -->
                            <div id="deliveryForm"
                                style="display: none; margin-top: 1rem; background: #fff; padding: 1rem; border-radius: 0.5rem; box-shadow: 0 0 8px rgba(0,0,0,0.2);">
                                <h5><strong>Option Delivery</strong></h5>
                                <form action="<?php echo e(route('customer.checkout')); ?>" method="POST" id="deliveryMethodForm">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery_method" id="pickup"
                                            value="pickup" required>
                                        <label class="form-check-label" for="pickup">Pick Up</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery_method" id="delivery"
                                            value="delivery" required>
                                        <label class="form-check-label" for="delivery">Delivery</label>
                                    </div>

                                    <button type="submit" class="btn btn-primary mt-3" disabled
                                        id="selectBtn">Select</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.js" crossorigin="anonymous"></script>
    <script>
        $(function() {
            var data = <?php echo json_encode($dataCart, 15, 512) ?>;
            var dataToShow = [];
            var totalharga = 0;

            $('input[name="cbox"]').on('change', function() {
                if ($(this).prop('checked')) {
                    var val = $(this).val();
                    var filtered = data.filter(function(d) {
                        return d.id == val;
                    });
                    totalharga += filtered[0]['jumlah'] * filtered[0]['price'];
                    dataToShow.push(filtered[0]);
                } else {
                    var val = $(this).val();
                    var idx = dataToShow.findIndex(d => d.id == val);
                    totalharga -= dataToShow[idx]['jumlah'] * dataToShow[idx]['price'];
                    dataToShow.splice(idx, 1);
                }

                if (dataToShow.length != 0) {
                    $('#item_detail').empty();
                    $('#item_detail').append("<p> Detail item :</p> ")
                    $.each(dataToShow, function(idx, d) {
                        var tot = d.jumlah * d.price;
                        $('#item_detail').append("<p style='font-size: 0.9rem;'><strong> -> " + d
                            .name + "</strong>,  <strong>" + d.price.toString().replace(
                                /\B(?=(\d{3})+(?!\d))/g, ",") + "</strong> X <strong> " + d
                            .jumlah + " Pcs  = " + tot.toString().replace(
                                /\B(?=(\d{3})+(?!\d))/g, ",") + "</strong></p>")
                    });
                    $('#item_detail').append(
                        "<h5 class='ps-3 position-absolute bottom-0 start-0' >Harga total : Rp. <strong>" +
                        totalharga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "</strong> </h5> "
                    )
                    $('#item_detail').append(
                        " <button type='submit' class='btn btn-warning position-absolute bottom-0 end-0'> Lanjut ke Checkout </button>"
                    )
                } else {
                    $('#item_detail').empty();
                }
            });
        })

        $(document).ready(function() {
            $('#optionDelivery').on('click', function() {
                $('#deliveryForm').slideToggle();
            });

            $('input[name="delivery_method"]').on('change', function() {
                $('#selectBtn').prop('disabled', false);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEMESTER 8\TA_SmileGiftShop\resources\views/customer/cart.blade.php ENDPATH**/ ?>