<?php $__env->startSection('title', 'Edit Bundle'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Smile Gift Shop</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home"><a href="#"><i class="icon-home"></i></a></li>
            <li class="separator"><i class="icon-arrow-right"></i></li>
            <li class="nav-item"><a href="#">Bundles</a></li>
            <li class="separator"><i class="icon-arrow-right"></i></li>
            <li class="nav-item"><a href="#">Edit Bundle</a></li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Edit Bundle</h4>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <p class="alert alert-danger"><?php echo e(session('error')); ?></p>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.product.bundle.update', $bundle->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row mb-3">
                            <div class="col">
                                <label for="name" class="form-label">Bundle Name</label>
                                <input type="text" name="name" id="name" class="form-control"
                                    value="<?php echo e(old('name', $bundle->name)); ?>" required>
                            </div>
                            <div class="col">
                                <label for="price" class="form-label">Bundle Price</label>
                                <input type="number" name="price" id="price" class="form-control"
                                    value="<?php echo e(old('price', $bundle->price)); ?>" required>
                            </div>
                        </div>

                        <div id="product-group">
                            <?php $__currentLoopData = $bundle->productsHasBundles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productBundle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-3 product-item">
                                    <div class="col-md-6">
                                        <label class="form-label">Product</label>
                                        <select name="products[]" class="form-select" required>
                                            <option value="">-- Select Product --</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>"
                                                    <?php echo e($product->id == $productBundle->products_id ? 'selected' : ''); ?>>
                                                    <?php echo e($product->name); ?> (Stock: <?php echo e($product->stock); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Quantity</label>
                                        <input type="number" name="quantities[]" class="form-control" min="1"
                                            value="<?php echo e($productBundle->quantity); ?>" required>
                                    </div>
                                    <div class="col-md-2 d-flex align-items-end">
                                        <button type="button" class="btn btn-danger remove-btn">Remove</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mb-3">
                            <button type="button" id="add-product" class="btn btn-secondary">+ Add Product</button>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Bundle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const productGroup = document.getElementById('product-group');
    const addProductButton = document.getElementById('add-product');

    addProductButton.addEventListener('click', () => {
        const item = productGroup.querySelector('.product-item');
        const clone = item.cloneNode(true);
        clone.querySelector('select').selectedIndex = 0;
        clone.querySelector('input').value = '';
        productGroup.appendChild(clone);
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-btn')) {
            const items = document.querySelectorAll('.product-item');
            if (items.length > 1) {
                e.target.closest('.product-item').remove();
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backoffice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEMESTER 8\TA_SmileGiftShop\resources\views/admin/product/bundle/edit.blade.php ENDPATH**/ ?>