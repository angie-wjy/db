<?php if(session('succ')): ?>
<div class="alert alert-success position-fixed bottom-0 end-0 m-3 alert-dismissible fade show" id="alert" role="alert">
    <strong>Success!</strong> <?php echo e(session('succ')); ?>

    
</div>
<?php endif; ?>
<?php if(session('err')): ?>
<div class="alert alert-danger position-fixed bottom-0 end-0 m-3 alert-dismissible fade show" id="alert" role="alert">
    <strong><?php echo e(session('err')); ?></strong>
    
</div>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script>
    $(function(){
        setTimeout(function() {
            $('#alert').fadeOut(500,function(){
                $(this).remove();
            });
        }, 2000);
    })
</script>
<?php /**PATH C:\xampp\htdocs\SEMESTER 8\TA_SmileGiftShop\resources\views/component/notification.blade.php ENDPATH**/ ?>